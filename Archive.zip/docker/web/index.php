<?php

phpinfo();